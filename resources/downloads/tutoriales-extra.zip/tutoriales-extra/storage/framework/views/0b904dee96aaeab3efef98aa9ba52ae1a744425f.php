<?php $__env->startPush('stylesheets'); ?>
<?php echo Html::style('http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/themes/south-street/jquery-ui.min.css'); ?>

<?php echo Html::style('components/plupload/js/jquery.ui.plupload/css/jquery.ui.plupload.css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-offset-2 col-md-8">
            <h2 class="text-center text-info">
                <?php if(isset($editable)): ?>
                    Edición de archivos
                <?php else: ?>
                    Subida de archivos
                <?php endif; ?>
            </h2>
            <hr />

            <!-- formulario para crear y actualizar -->
            <?php echo $__env->make('albums.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- ./formulario para crear y actualizar -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php echo Html::script('components/jquery-ui/jquery-ui.min.js'); ?>


<?php echo Html::script('components/plupload/js/plupload.full.min.js'); ?>


<?php echo Html::script('components/plupload/js/jquery.ui.plupload/jquery.ui.plupload.min.js'); ?>

<?php echo Html::script('components/plupload/js/i18n/es.js'); ?>


<script type="text/javascript">
    function remove_file(file_id)
    {
        $.ajax({
            type: 'DELETE',
            url: '<?php echo route('pictures.remove'); ?>',
            data: {
                fileId: file_id,
                _token: $('meta[name="csrf-token"]').attr('content'),
            }
        })
    }

    var section = null;

    $(function ()
    {
        $("#plupload1, #plupload2, #plupload3").on("click", function()
        {
            section = $(this).attr("id");
        })

        $("#plupload1, #plupload2, #plupload3").plupload({
            url : '<?php echo route('pictures.upload'); ?>',
            runtimes : 'html5,flash,silverlight,html4',
            unique_names : true,
            chunk_size: '1mb',
            filters : {
                max_file_size : '2mb',
                mime_types: [
                    {title : "Archivos de imagen", extensions : "jpg,png"}
                ]
            },
            views: {
                list: true,
                thumbs: true,
                active: 'thumbs'
            },
            flash_swf_url : '<?php echo URL::to('components/plupload/js/Moxie.swf'); ?>',
            silverlight_xap_url : '<?php echo URL::to('components/plupload/js/Moxie.xap'); ?>',
            preinit : {
                UploadFile: function(up, file)
                {
                    up.setOption('multipart_params', {
                        file_id : file.id,
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        section: section,
                        album_id: $("input[name=album_id]").val()
                    });
                }
            },
            init : {
                FilesRemoved: function(up, files)
                {
                    plupload.each(files, function(file)
                    {
                        remove_file(file.id)
                    });
                },
            },
            buttons:{
                browse: true,
                start: true,
                stop: false
            }
        });
    })
</script>

<?php if(isset($editable)): ?>

    <?php if($album->pictures): ?>

		<?php $plupload1 = $plupload2 = $plupload3 = [] ?>
        <?php $__currentLoopData = $album->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($picture->file_section == 'plupload1'): ?>
				<?php array_push($plupload1, $picture) ?>
            <?php elseif($picture->file_section == 'plupload2'): ?>
				<?php array_push($plupload2, $picture) ?>
            <?php elseif($picture->file_section == 'plupload3'): ?>
				<?php array_push($plupload3, $picture) ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php endif; ?>

    <?php if(!empty($plupload1)): ?>
        <?php echo $__env->make('albums.pluploads.standard_plupload', ['section' => 'plupload1', 'pictures' => $plupload1], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($plupload2)): ?>
        <?php echo $__env->make('albums.pluploads.standard_plupload', ['section' => 'plupload2', 'pictures' => $plupload2], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($plupload3)): ?>
        <?php echo $__env->make('albums.pluploads.standard_plupload', ['section' => 'plupload3', 'pictures' => $plupload3], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>