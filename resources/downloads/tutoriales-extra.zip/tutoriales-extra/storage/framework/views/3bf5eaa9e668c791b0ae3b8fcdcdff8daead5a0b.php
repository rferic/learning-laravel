<?php if(isset($editable)): ?>
    <?php echo Form::model($album, ['route' => ['albums.update', $album->id], 'method' => 'PUT']); ?>

<?php else: ?>
    <?php echo Form::model($album, ['route' => 'albums.store']); ?>

<?php endif; ?>

<?php echo Form::hidden('album_id', $album->id); ?>


<div class="col-md-12 form-group">
    <?php echo Form::label('name', 'Nombre del albúm', ['class' => 'text-success']); ?>

    <?php echo Form::text('name', old('name'), ['class' => 'form-control']); ?>

</div>

<div class="col-md-12 form-group">
    <?php echo Form::label('plupload1', 'Imágenes del plupload 1', ['class' => 'text-success']); ?>

    <div id="plupload1">
        <p>Your browser doesn't have Flash, Silverlight or HTML5 support.</p>
    </div>
</div>

<div class="col-md-12 form-group">
    <?php echo Form::label('plupload2', 'Imágenes del plupload 2', ['class' => 'text-success']); ?>

    <div id="plupload2">
        <p>Your browser doesn't have Flash, Silverlight or HTML5 support.</p>
    </div>
</div>

<div class="col-md-12 form-group">
    <?php echo Form::label('plupload3', 'Imágenes del plupload 3', ['class' => 'text-success']); ?>

    <div id="plupload3">
        <p>Your browser doesn't have Flash, Silverlight or HTML5 support.</p>
    </div>
</div>

<div class="col-md-12 form-group">
    <?php if(!isset($editable)): ?>
        <?php echo Form::submit('Crear albúm', ['class' => 'btn btn-success btn-block']); ?>

    <?php else: ?>
        <?php echo Form::submit('Actualizar albúm', ['class' => 'btn btn-success btn-block']); ?>

    <?php endif; ?>
</div>

<?php echo Form::close(); ?>