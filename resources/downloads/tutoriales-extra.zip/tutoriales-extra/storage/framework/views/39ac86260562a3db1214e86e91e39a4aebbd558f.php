<script>
    $(function () {
        $("#" + '<?php echo e($section); ?>').plupload({
            init: {
                Init: function (up)
                {
                    var total_size = 0;
                    <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        var file = new plupload.File('<?php echo e('/pictures/' . $picture->filename); ?>', '<?php echo e($picture->file_id); ?>', '<?php echo e($picture->file_size); ?>');
                        file.name = '<?php echo e($picture->original_name); ?>';
                        file.size = '<?php echo e($picture->file_size); ?>';
                        file.destroy = function()
                        {
                            remove_file('<?php echo e($picture->file_id); ?>')
                        }
                        file.percent = 100;
                        file.loaded = '<?php echo e($picture->file_size); ?>';
                        file.status = plupload.DONE;
                        up.addFile(file);
                        total_size += parseFloat('<?php echo e($picture->file_size); ?>');
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                    var queueprogress = new plupload.QueueProgress();
                    queueprogress.size = total_size;
                    queueprogress.uploaded = total_size;
                    queueprogress.percent = 100;
                    up.total = queueprogress;

                    up.trigger("QueueChanged");
                    up.trigger('UploadComplete')
                    up.refresh();
                }
            }
        })
    })
</script>