<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="col-md-12">

            <a class="btn btn-success pull-right" href="/profile">Mi perfil</a>
            <div class="clearfix"></div>

            <div class="panel panel-info">

                <div class="panel-heading">
                    <div class="panel-title">
                        Facturas
                    </div>
                </div>

                <div class="panel-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Fecha de la suscripción</th>
                                <th>Coste de la suscripción</th>
                                <th>Cupón</th>
                                <th>Descargar factura</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($invoice->date()->toFormattedDateString()); ?></td>
                                <td><?php echo e($invoice->total()); ?></td>
                                <?php if($invoice->hasDiscount()): ?>
                                    <td>Cupón:  (<?php echo e($invoice->coupon()); ?> / <?php echo e($invoice->discount()); ?>)</td>
                                <?php else: ?>
                                    <td>No se ha utilizado ningún cupón</td>
                                <?php endif; ?>
                                <td><a href="/invoice/<?php echo e($invoice->id); ?>">Descargar</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>