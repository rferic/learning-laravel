<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <?php if(auth()->user()->subscriptions->count()): ?>
            <a class="btn btn-success pull-right" href="/invoices">Mis facturas</a>
            <div class="clearfix"></div>
        <?php endif; ?>

        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="panel-title">
                        StripeId: <?php echo e($subscription->stripe_id); ?>

                    </div>
                </div>

                <div class="panel-body">
                    <p>Tipo de suscripción: <b><?php echo e($subscription->stripe_plan); ?></b></p>
                    <p>Contratado desde: <b><?php echo e($subscription->created_at->format('d/m/Y')); ?></b></p>

                    <!--si está en período de gracia-->
                    <?php if(auth()->user()->subscription($subscription->name)->onGracePeriod()): ?>
                        <hr />
                        Suscripción Cancelada: <b>Vigente hasta <?php echo e($subscription->ends_at->format('d/m/Y H:i:s')); ?></b>&nbsp;

                        <!-- reanudar suscripción -->
                        <form style="display: inline;" action="subscription/resume" method="POST">
                            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
                            <input type="hidden" name="plan" value="<?php echo e($subscription->name); ?>" />
                            <button class="btn btn-sm btn-warning">
                                Reanudar suscripción
                            </button>
                        </form>
                        <!-- ./reanudar suscripción -->
                    <?php endif; ?>
                </div>
                <div class="panel-footer">

                    <a href="subscription/cancel/<?php echo e($subscription->name); ?>" class="btn btn-sm btn-danger">
                        Cancelar suscripción
                    </a>
                    <?php if($subscription->stripe_plan != 'yearly'): ?>
                        <form style="display: inline;" action="subscription/upgrade" method="POST">
                            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
                            <input type="hidden" name="plan" value="<?php echo e($subscription->name); ?>" />
                            <input type="hidden" name="stripe_plan" value="<?php echo e($subscription->stripe_plan); ?>" />
                            <button class="btn btn-sm btn-warning">
                                Subir suscripción
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
            <div class="alert alert-danger col-md-4 col-md-offset-4 text-center">No tiene suscripciones</div>
            <a class="btn btn-info col-md-4 col-md-offset-4" href="/subscription">Contratar un plan</a>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>