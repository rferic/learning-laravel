<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(link_to_action(
            'Admin\IngredientController@create',
            'Crear ingrediente',
            [],
            ["class" => "btn btn-md btn-success pull-right"]
        )); ?>


    <br><hr>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Precio</th>
                <th width="12%">Editar</th>
            </tr>
        </thead>
        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($ingredient->id); ?></td>
                    <td><?php echo e($ingredient->name); ?></td>
                    <td><?php echo e($ingredient->price); ?></td>
                    <td>
                        <?php echo e(link_to_action('Admin\IngredientController@edit', 'Edit ingredient', ["id" => $ingredient->id], ["class" => "btn btn-xs btn-info"])); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No hay ingredientes</td>
                </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <?php if($ingredients): ?>
        <?php echo e($ingredients->links()); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>