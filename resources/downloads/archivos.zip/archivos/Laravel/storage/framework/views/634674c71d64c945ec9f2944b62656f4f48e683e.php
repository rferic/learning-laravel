<?php $__env->startSection('title', 'Pizzas del usuario'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">

        <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <hr />

        <?php echo $__env->make('partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__empty_1 = true; $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($pizza->name); ?></div>

                <div class="panel-body">
                    <p>Precio: <?php echo e($pizza->price); ?></p>
                    <?php echo e($pizza->description); ?>

                </div>

                <div class="panel-footer" style="height: 45px;">
                    <?php echo e(link_to_action(
                            'PizzaController@edit', 'Editar', ['id' => $pizza->id], ['class' => 'col-md-2']
                        )); ?>


                    <?php if($pizza->trashed()): ?>
                        <?php echo Form::open(['method' => 'PATCH', 'route' => ['pizzas.restore', $pizza->id]]); ?>

                            <?php echo Form::submit('Restaurar', ["class" => "btn btn-xs btn-warning col-md-2"]); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>

                    <span class="pull-right">
                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['pizzas.destroy', $pizza->id]]); ?>

                            <?php echo Form::submit('Eliminar', ["class" => "btn btn-xs btn-danger"]); ?>

                        <?php echo Form::close(); ?>

                    </span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
            <div class="alert alert-danger">
                No hay pizzas
            </div>
        <?php endif; ?>

        <?php if($pizzas): ?>
            <?php echo e($pizzas->links()); ?>

        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>