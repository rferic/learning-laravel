<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre de la pizza</th>
                <th>Precio de la pizza</th>
                <th>Ingredientes</th>
                <th width="10%">Editar</th>
                <th width="10%">Eliminar</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($pizza->id); ?></td>
                    <td><?php echo e($pizza->name); ?></td>
                    <td><?php echo e($pizza->price); ?></td>

                    <td>
                        <?php if($pizza->ingredients): ?>
                            <?php $arr = [] ?>
                            <?php $__currentLoopData = $pizza->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php array_push($arr, $ingredient->name) ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php echo join(', ', $arr) ?>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php echo e(link_to_action('Admin\IngredientPizzaController@edit', 'Edit pizza ingredient', ["id" => $pizza->id], ["class" => "btn btn-xs btn-info"])); ?>

                    </td>

                    <td>
                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['admin.ingredients_pizzas.destroy', $pizza->id]]); ?>

                        <?php echo Form::submit("Delete pizza ingredient relation", ["class" => "btn btn-xs btn-danger"]); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <tr class="alert alert-danger">
                    <td colspan="6">No hay pizzas</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if($pizzas): ?>
        <?php echo $pizzas->links(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>