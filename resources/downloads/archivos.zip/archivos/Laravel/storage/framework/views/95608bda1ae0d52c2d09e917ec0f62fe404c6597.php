<p>
    <?php echo e(link_to_action('PizzaController@create', 'Crear una pizza', [], [])); ?> |
    <?php echo e(link_to_action('PizzaController@index', 'Mis pizzas', [], [])); ?>


    <?php if(auth()->user()->role_id === 1): ?>
        | <?php echo e(link_to_route('admin.panel', 'Administración', [])); ?>

    <?php endif; ?>
</p>
