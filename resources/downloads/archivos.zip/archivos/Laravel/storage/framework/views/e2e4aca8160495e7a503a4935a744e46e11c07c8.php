<?php $__env->startSection('content'); ?>

    <div class="container">

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo Form::model(
            $pizza,
            ['route' => ['pizzas.update', $pizza->id],
            'class' => 'form-horizontal',
            'method' => 'PUT',
            'id' => 'edit-pizza'
            ]
        ); ?>


        <?php echo e(Form::hidden('user_id', auth()->user()->id)); ?>


        <?php echo e(Form::hidden('id', $pizza->id)); ?>


        <div class="form-group">
            <?php echo Form::label('name', 'Nombre'); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('price', 'Precio'); ?>

            <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('description', 'Descripción'); ?>

            <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

        </div>

        <?php echo Form::submit('Editar pizza', ['class' => 'btn btn-success']); ?>


        <?php echo Form::close(); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>