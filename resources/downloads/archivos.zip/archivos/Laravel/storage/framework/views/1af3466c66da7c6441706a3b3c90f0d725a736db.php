<div class="col-md-12">
    <?php echo e(link_to_action('Admin\PizzaController@index', 'Pizzas', [], [])); ?> |
    <?php echo e(link_to_action('Admin\UserController@index', 'Usuarios', [], [])); ?> |
    <?php echo e(link_to_action('Admin\IngredientController@index', 'Ingredientes', [], [])); ?> |
    <?php echo e(link_to_action('Admin\IngredientPizzaController@index', 'Ingredient y Pizzas', [], [])); ?> |
    <?php echo e(link_to_action('AdminController@index', 'Administración', [])); ?>

</div>

<hr />