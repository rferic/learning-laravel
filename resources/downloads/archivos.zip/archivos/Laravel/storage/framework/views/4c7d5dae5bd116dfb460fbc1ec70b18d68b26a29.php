<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo Form::open(
            [
                'route' => ['admin.ingredients_pizzas.update', $pizza->id],
                'method' => 'PUT'
            ]); ?>


            <?php echo Form::hidden('pizza', $pizza->id); ?>


            <div class="form-group">
                <?php echo Form::label('pizza_id', 'Pizza'); ?>

                <?php echo Form::select('pizza_id', $pizzas, $pizza->id, ['class' => 'form-control', 'disabled']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('ingredients[]', 'Ingredientes'); ?>

                <?php echo Form::select(
                        'ingredients[]',
                        $ingredients,
                        $pizza->ingredients()->pluck('id')->toArray(),
                        ['class' => 'form-control', 'multiple']); ?>

            </div>

            <?php echo e(Form::submit('Editar relación pizza + ingrediente!', ["class" => "btn btn-success"])); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>