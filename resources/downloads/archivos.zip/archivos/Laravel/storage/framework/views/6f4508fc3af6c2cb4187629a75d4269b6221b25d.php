<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo Form::model(
            $ingredient,
            ['route' => ['admin.ingredients.update', $ingredient->id],
            'class' => 'form-horizontal',
            'method' => 'PUT',
            'id' => 'edit-ingredient'
            ]
        ); ?>


    <div class="form-group">
        <?php echo Form::label('name', 'Nombre'); ?>

        <?php echo Form::text('name', old('name'), ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('price', 'Precio'); ?>

        <?php echo Form::text('price', old('price'), ['class' => 'form-control']); ?>

    </div>

    <?php echo Form::submit('Actualizar ingrediente', ['class' => 'btn btn-success']); ?>


    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>